import { Link, useLocation } from "wouter";
import { Search, BookOpen, Palette, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import SearchBar from "./search-bar";

export default function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <div className="flex-shrink-0">
              <Link href="/" data-testid="link-home">
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent cursor-pointer">
                  MangaVerse
                </h1>
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link href="/browse" data-testid="link-browse">
                  <a className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location === '/browse' ? 'text-foreground' : 'text-muted-foreground hover:text-primary'
                  }`}>
                    Browse
                  </a>
                </Link>
                <Link href="/library" data-testid="link-library">
                  <a className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    location === '/library' ? 'text-foreground' : 'text-muted-foreground hover:text-primary'
                  }`}>
                    Library
                  </a>
                </Link>
                <Link href="/trending" data-testid="link-trending">
                  <a className="text-muted-foreground hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors">
                    Trending
                  </a>
                </Link>
                <Link href="/updates" data-testid="link-updates">
                  <a className="text-muted-foreground hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors">
                    Updates
                  </a>
                </Link>
              </div>
            </div>
          </div>

          <div className="hidden md:block flex-1 max-w-lg mx-8">
            <SearchBar />
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary" data-testid="button-reading-mode">
              <BookOpen className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary" data-testid="button-theme">
              <Palette className="h-5 w-5" />
            </Button>
            <div className="relative">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary" data-testid="button-profile">
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center">
                  <User className="h-4 w-4 text-white" />
                </div>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
