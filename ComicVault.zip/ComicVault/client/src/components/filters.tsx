import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

interface FiltersProps {
  onFiltersChange: (filters: {
    type?: string;
    status?: string;
    genres?: string[];
  }) => void;
}

const GENRES = [
  "Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror",
  "Mystery", "Romance", "Sci-Fi", "Slice of Life", "Sports", "Supernatural",
  "Thriller", "Tragedy", "Historical", "Psychological", "School", "Martial Arts"
];

export default function Filters({ onFiltersChange }: FiltersProps) {
  const [selectedType, setSelectedType] = useState<string>("");
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);

  const handleTypeChange = (value: string) => {
    const newType = value === "all" ? "" : value;
    setSelectedType(newType);
    onFiltersChange({
      type: newType || undefined,
      status: selectedStatus || undefined,
      genres: selectedGenres.length > 0 ? selectedGenres : undefined,
    });
  };

  const handleStatusChange = (value: string) => {
    const newStatus = value === "all" ? "" : value;
    setSelectedStatus(newStatus);
    onFiltersChange({
      type: selectedType || undefined,
      status: newStatus || undefined,
      genres: selectedGenres.length > 0 ? selectedGenres : undefined,
    });
  };

  const handleGenreChange = (genre: string, checked: boolean) => {
    const newGenres = checked
      ? [...selectedGenres, genre]
      : selectedGenres.filter(g => g !== genre);
    
    setSelectedGenres(newGenres);
    onFiltersChange({
      type: selectedType || undefined,
      status: selectedStatus || undefined,
      genres: newGenres.length > 0 ? newGenres : undefined,
    });
  };

  const clearFilters = () => {
    setSelectedType("");
    setSelectedStatus("");
    setSelectedGenres([]);
    onFiltersChange({});
  };

  return (
    <Card className="p-6 sticky top-24">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">Filters</h4>
        <Button variant="ghost" size="sm" onClick={clearFilters} data-testid="button-clear-filters">
          Clear
        </Button>
      </div>

      <div className="space-y-6">
        <div>
          <Label className="text-sm font-medium text-muted-foreground mb-2 block">Type</Label>
          <Select value={selectedType || "all"} onValueChange={handleTypeChange}>
            <SelectTrigger data-testid="select-type">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="manga">Manga</SelectItem>
              <SelectItem value="manhwa">Manhwa</SelectItem>
              <SelectItem value="webtoon">Webtoon</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-sm font-medium text-muted-foreground mb-2 block">Status</Label>
          <Select value={selectedStatus || "all"} onValueChange={handleStatusChange}>
            <SelectTrigger data-testid="select-status">
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="ongoing">Ongoing</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="hiatus">Hiatus</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-sm font-medium text-muted-foreground mb-2 block">Genres</Label>
          <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-hide">
            {GENRES.map((genre) => (
              <div key={genre} className="flex items-center space-x-2">
                <Checkbox
                  id={genre}
                  checked={selectedGenres.includes(genre)}
                  onCheckedChange={(checked) => handleGenreChange(genre, checked as boolean)}
                  data-testid={`checkbox-genre-${genre.toLowerCase().replace(/\s+/g, '-')}`}
                />
                <Label htmlFor={genre} className="text-sm cursor-pointer">
                  {genre}
                </Label>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}
