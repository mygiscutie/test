import { Heart, Star } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { type Manga } from "@shared/schema";

interface MangaCardProps {
  manga: Manga;
  showSource?: boolean;
  className?: string;
}

export default function MangaCard({ manga, showSource = true, className = "" }: MangaCardProps) {
  const getSourceColor = (source: string) => {
    switch (source) {
      case 'asura':
        return 'bg-green-500';
      case 'bato':
        return 'bg-purple-500';
      case 'flame':
        return 'bg-orange-500';
      case 'webtoon':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <Link href={`/manga/${manga.id}`} data-testid={`card-manga-${manga.id}`}>
      <Card className={`manga-card group cursor-pointer overflow-hidden ${className}`}>
        <div className="relative aspect-[3/4] overflow-hidden bg-card">
          <img
            src={manga.coverImage || "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600"}
            alt={`${manga.title} cover`}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            data-testid={`img-cover-${manga.id}`}
          />
          
          {showSource && (
            <div className="absolute top-2 left-2">
              <Badge className={`${getSourceColor(manga.source)} text-white text-xs font-medium`}>
                {manga.source.toUpperCase()}
              </Badge>
            </div>
          )}
          
          <div className="absolute top-2 right-2">
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full text-white transition-colors"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                // TODO: Implement favorite toggle
              }}
              data-testid={`button-favorite-${manga.id}`}
            >
              <Heart className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
            <h4 className="font-semibold text-white text-sm truncate" data-testid={`text-title-${manga.id}`}>
              {manga.title}
            </h4>
            <p className="text-gray-300 text-xs mb-1" data-testid={`text-chapter-${manga.id}`}>
              Ch. {manga.latestChapter} • {manga.status}
            </p>
            {(manga.rating ?? 0) > 0 && (
              <div className="flex items-center space-x-1">
                <Star className="h-3 w-3 text-yellow-400 fill-current" />
                <span className="text-gray-300 text-xs" data-testid={`text-rating-${manga.id}`}>
                  {((manga.rating ?? 0) / 10).toFixed(1)}
                </span>
              </div>
            )}
          </div>
        </div>
      </Card>
    </Link>
  );
}
