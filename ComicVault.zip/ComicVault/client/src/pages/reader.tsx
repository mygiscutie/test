import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Settings, Home, List, ZoomIn, ZoomOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Link } from "wouter";
import { type Manga, type Chapter } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface ReaderProps {
  params: { mangaId: string; chapterId: string };
}

const MOCK_USER_ID = "user1";

export default function Reader({ params }: ReaderProps) {
  const [currentPage, setCurrentPage] = useState(0);
  const [readingMode, setReadingMode] = useState<"manga" | "manhwa">("manga");
  const [zoomLevel, setZoomLevel] = useState(100);
  const [autoMode, setAutoMode] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const { data: manga, isLoading: mangaLoading } = useQuery<Manga>({
    queryKey: ["/api/manga", params.mangaId],
  });

  const { data: chapter, isLoading: chapterLoading, error: chapterError } = useQuery<Chapter>({
    queryKey: ["/api/chapters", params.chapterId],
    retry: false,
  });

  const { data: allChapters } = useQuery<Chapter[]>({
    queryKey: ["/api/manga", params.mangaId, "chapters"],
    enabled: !!manga,
  });

  // Update reading progress
  const updateProgressMutation = useMutation({
    mutationFn: async (data: { pageNumber: number; isCompleted: boolean }) => {
      return apiRequest("POST", "/api/reading-progress", {
        userId: MOCK_USER_ID,
        mangaId: params.mangaId,
        chapterId: params.chapterId,
        pageNumber: data.pageNumber,
        scrollPosition: 0,
        isCompleted: data.isCompleted,
      });
    },
  });

  // Auto-detect reading mode based on manga type
  useEffect(() => {
    if (manga) {
      setReadingMode(manga.type === "manhwa" || manga.type === "webtoon" ? "manhwa" : "manga");
    }
  }, [manga]);

  // Update progress when page changes
  useEffect(() => {
    if (chapter && chapter.pages.length > 0) {
      const isCompleted = currentPage >= chapter.pages.length - 1;
      updateProgressMutation.mutate({
        pageNumber: currentPage,
        isCompleted,
      });
    }
  }, [currentPage, chapter, params.chapterId]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" || e.key === "a") {
        goToPreviousPage();
      } else if (e.key === "ArrowRight" || e.key === "d") {
        goToNextPage();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentPage, chapter]);

  const goToPreviousPage = useCallback(() => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  }, [currentPage]);

  const goToNextPage = useCallback(() => {
    if (chapter && currentPage < chapter.pages.length - 1) {
      setCurrentPage(currentPage + 1);
    }
  }, [currentPage, chapter]);

  const getCurrentChapterIndex = () => {
    if (!allChapters || !chapter) return -1;
    return allChapters.findIndex(c => c.id === chapter.id);
  };

  const getNextChapter = () => {
    if (!allChapters) return null;
    const currentIndex = getCurrentChapterIndex();
    return currentIndex >= 0 && currentIndex < allChapters.length - 1 
      ? allChapters[currentIndex + 1] 
      : null;
  };

  const getPreviousChapter = () => {
    if (!allChapters) return null;
    const currentIndex = getCurrentChapterIndex();
    return currentIndex > 0 ? allChapters[currentIndex - 1] : null;
  };

  if (mangaLoading || chapterLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin w-8 h-8 border-2 border-white border-t-transparent rounded-full mx-auto mb-4" />
          <p>Loading chapter...</p>
        </div>
      </div>
    );
  }

  if (!manga) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Manga Not Found</h1>
          <p className="text-muted-foreground mb-4">The manga you're looking for doesn't exist.</p>
          <Link href="/browse">
            <Button>Browse Manga</Button>
          </Link>
        </Card>
      </div>
    );
  }

  if (chapterError || !chapter) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Chapter Not Available</h1>
          <p className="text-muted-foreground mb-4">This chapter doesn't exist or hasn't been uploaded yet.</p>
          <div className="flex gap-4 justify-center">
            <Link href={`/manga/${params.mangaId}`}>
              <Button>Back to Manga</Button>
            </Link>
            <Link href="/browse">
              <Button variant="secondary">Browse Other Manga</Button>
            </Link>
          </div>
        </Card>
      </div>
    );
  }

  if (!chapter.pages || chapter.pages.length === 0) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Chapter Not Available</h1>
          <p className="text-muted-foreground mb-4">This chapter doesn't have any pages available yet.</p>
          <Link href={`/manga/${params.mangaId}`}>
            <Button>Back to Manga</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Top Navigation */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm border-b border-gray-800">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center space-x-4">
            <Link href={`/manga/${params.mangaId}`}>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" data-testid="button-back-to-manga">
                <Home className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="font-semibold truncate max-w-xs" data-testid="text-manga-title">
                {manga.title}
              </h1>
              <p className="text-sm text-gray-400" data-testid="text-chapter-info">
                Chapter {chapter.chapterNumber}
                {chapter.title && `: ${chapter.title}`}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Dialog open={showSettings} onOpenChange={setShowSettings}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" data-testid="button-settings">
                  <Settings className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card text-foreground">
                <DialogHeader>
                  <DialogTitle>Reader Settings</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Reading Mode</Label>
                    <Select value={readingMode} onValueChange={(value: "manga" | "manhwa") => setReadingMode(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="manga">Manga (Page-by-Page)</SelectItem>
                        <SelectItem value="manhwa">Manhwa (Vertical Scroll)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-medium mb-2 block">Zoom Level: {zoomLevel}%</Label>
                    <Slider
                      value={[zoomLevel]}
                      onValueChange={(value) => setZoomLevel(value[0])}
                      min={50}
                      max={200}
                      step={10}
                      className="w-full"
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id="auto-mode"
                      checked={autoMode}
                      onCheckedChange={setAutoMode}
                    />
                    <Label htmlFor="auto-mode">Auto-scroll Mode</Label>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Link href="/browse">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" data-testid="button-browse">
                <List className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Reader Content */}
      <div className="pt-16">
        {readingMode === "manga" ? (
          // Manga Mode - Page by Page
          <div className="relative h-screen flex items-center justify-center">
            <div
              className="relative max-w-full max-h-full overflow-hidden"
              style={{ transform: `scale(${zoomLevel / 100})` }}
            >
              <img
                src={chapter.pages[currentPage]}
                alt={`Page ${currentPage + 1}`}
                className="max-w-full max-h-full object-contain"
                data-testid={`img-page-${currentPage}`}
              />
            </div>

            {/* Navigation Arrows */}
            {currentPage > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:bg-white/10 w-12 h-12"
                onClick={goToPreviousPage}
                data-testid="button-previous-page"
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
            )}

            {currentPage < chapter.pages.length - 1 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:bg-white/10 w-12 h-12"
                onClick={goToNextPage}
                data-testid="button-next-page"
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            )}

            {/* Page Counter */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/80 backdrop-blur-sm px-4 py-2 rounded-lg">
              <span className="text-sm" data-testid="text-page-counter">
                {currentPage + 1} / {chapter.pages.length}
              </span>
            </div>
          </div>
        ) : (
          // Manhwa Mode - Vertical Scroll
          <div className="space-y-0" style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}>
            {chapter.pages.map((page, index) => (
              <img
                key={index}
                src={page}
                alt={`Panel ${index + 1}`}
                className="w-full block"
                data-testid={`img-panel-${index}`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm border-t border-gray-800">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center space-x-2">
            {getPreviousChapter() && (
              <Link href={`/read/${params.mangaId}/${getPreviousChapter()!.id}`}>
                <Button variant="ghost" size="sm" className="text-white hover:bg-white/10" data-testid="button-previous-chapter">
                  ← Prev Chapter
                </Button>
              </Link>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoomLevel(Math.max(50, zoomLevel - 10))}
              className="text-white hover:bg-white/10"
              data-testid="button-zoom-out"
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <span className="text-sm px-2">{zoomLevel}%</span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoomLevel(Math.min(200, zoomLevel + 10))}
              className="text-white hover:bg-white/10"
              data-testid="button-zoom-in"
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            {getNextChapter() && (
              <Link href={`/read/${params.mangaId}/${getNextChapter()!.id}`}>
                <Button variant="ghost" size="sm" className="text-white hover:bg-white/10" data-testid="button-next-chapter">
                  Next Chapter →
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
