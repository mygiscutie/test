import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Book, Clock, TrendingUp, Heart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import MangaCard from "@/components/manga-card";
import { Link } from "wouter";
import { type Manga } from "@shared/schema";

const MOCK_USER_ID = "user1";

interface LibraryItem {
  id: string;
  userId: string;
  mangaId: string;
  status: string;
  currentChapter: number;
  isFavorite: boolean;
  manga: Manga;
}

interface UserStats {
  totalManga: number;
  planToRead: number;
  reading: number;
  completed: number;
  onHold: number;
  dropped: number;
  chaptersRead: number;
  readingStreak: number;
  favoriteGenre: string;
  hoursRead: number;
  monthlyGoalProgress: number;
}

export default function Library() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: library, isLoading: libraryLoading } = useQuery<LibraryItem[]>({
    queryKey: ["/api/library", MOCK_USER_ID],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ["/api/stats", MOCK_USER_ID],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'reading':
        return 'bg-green-500';
      case 'completed':
        return 'bg-blue-500';
      case 'plan_to_read':
        return 'bg-yellow-500';
      case 'on_hold':
        return 'bg-orange-500';
      case 'dropped':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'plan_to_read':
        return 'Plan to Read';
      case 'reading':
        return 'Reading';
      case 'completed':
        return 'Completed';
      case 'on_hold':
        return 'On Hold';
      case 'dropped':
        return 'Dropped';
      default:
        return status;
    }
  };

  const libraryByStatus = library?.reduce((acc, item) => {
    acc[item.status] = (acc[item.status] || []).concat(item);
    return acc;
  }, {} as Record<string, LibraryItem[]>) || {};

  const currentlyReading = libraryByStatus.reading || [];
  const favorites = library?.filter(item => item.isFavorite) || [];

  const pieData = stats ? [
    { name: 'Plan to Read', value: stats.planToRead, color: '#eab308' },
    { name: 'Reading', value: stats.reading, color: '#22c55e' },
    { name: 'Completed', value: stats.completed, color: '#3b82f6' },
    { name: 'On Hold', value: stats.onHold, color: '#f97316' },
    { name: 'Dropped', value: stats.dropped, color: '#ef4444' },
  ] : [];

  if (libraryLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-8">
            <div className="h-12 bg-muted rounded w-1/3" />
            <div className="grid lg:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-32 bg-muted rounded" />
              ))}
            </div>
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="h-96 bg-muted rounded" />
              <div className="lg:col-span-2 h-96 bg-muted rounded" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">My Library</h1>
          <p className="text-muted-foreground">Track your reading journey and discover new favorites</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="reading" data-testid="tab-reading">Reading</TabsTrigger>
            <TabsTrigger value="completed" data-testid="tab-completed">Completed</TabsTrigger>
            <TabsTrigger value="favorites" data-testid="tab-favorites">Favorites</TabsTrigger>
            <TabsTrigger value="all" data-testid="tab-all">All</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Manga</CardTitle>
                  <Book className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-total-manga">{stats?.totalManga || 0}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Chapters Read</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-chapters-read">{stats?.chaptersRead || 0}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Reading Streak</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-reading-streak">{stats?.readingStreak || 0} days</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Hours Read</CardTitle>
                  <Heart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-hours-read">{stats?.hoursRead || 0}h</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Reading Progress */}
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Goal</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">
                      {stats?.monthlyGoalProgress || 0}%
                    </div>
                    <Progress value={stats?.monthlyGoalProgress || 0} className="w-full" />
                    <p className="text-sm text-muted-foreground mt-2">Monthly Reading Goal</p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Favorite Genre</span>
                      <Badge className="genre-tag">{stats?.favoriteGenre || 'N/A'}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Library Breakdown */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Library Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-600" data-testid="stat-plan-to-read">
                        {stats?.planToRead || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Plan to Read</div>
                    </div>
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600" data-testid="stat-reading">
                        {stats?.reading || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Reading</div>
                    </div>
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600" data-testid="stat-completed">
                        {stats?.completed || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Completed</div>
                    </div>
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600" data-testid="stat-on-hold">
                        {stats?.onHold || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">On Hold</div>
                    </div>
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <div className="text-2xl font-bold text-red-600" data-testid="stat-dropped">
                        {stats?.dropped || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Dropped</div>
                    </div>
                  </div>

                  {pieData.length > 0 && (
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Continue Reading */}
            {currentlyReading.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Continue Reading</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {currentlyReading.slice(0, 3).map((item) => (
                      <Link key={item.id} href={`/manga/${item.mangaId}`}>
                        <div className="flex items-center space-x-4 p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer" data-testid={`continue-reading-${item.id}`}>
                          <img
                            src={item.manga.coverImage || "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=80"}
                            alt={`${item.manga.title} cover`}
                            className="w-12 h-16 object-cover rounded"
                          />
                          <div className="flex-1">
                            <h6 className="font-medium">{item.manga.title}</h6>
                            <p className="text-sm text-muted-foreground">
                              Chapter {item.currentChapter} of {item.manga.latestChapter}
                            </p>
                            <div className="w-full bg-muted rounded-full h-2 mt-2">
                              <div
                                className="bg-primary h-2 rounded-full"
                                style={{
                                  width: `${Math.min(100, (item.currentChapter / (item.manga.latestChapter ?? 1)) * 100)}%`
                                }}
                              />
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium">
                              {Math.max(0, (item.manga.latestChapter ?? 0) - item.currentChapter)} left
                            </div>
                            <div className="text-xs text-muted-foreground">chapters</div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="reading" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">Currently Reading</h2>
              <span className="text-muted-foreground">{currentlyReading.length} titles</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-6">
              {currentlyReading.map((item) => (
                <MangaCard key={item.id} manga={item.manga} showSource={false} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">Completed</h2>
              <span className="text-muted-foreground">{libraryByStatus.completed?.length || 0} titles</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-6">
              {(libraryByStatus.completed || []).map((item) => (
                <MangaCard key={item.id} manga={item.manga} showSource={false} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="favorites" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">Favorites</h2>
              <span className="text-muted-foreground">{favorites.length} titles</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-6">
              {favorites.map((item) => (
                <MangaCard key={item.id} manga={item.manga} showSource={false} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="all" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">All Manga</h2>
              <span className="text-muted-foreground">{library?.length || 0} titles</span>
            </div>
            <div className="space-y-8">
              {Object.entries(libraryByStatus).map(([status, items]) => (
                <div key={status}>
                  <div className="flex items-center space-x-3 mb-4">
                    <Badge className={getStatusColor(status)}>
                      {getStatusLabel(status)}
                    </Badge>
                    <span className="text-muted-foreground">{items.length} titles</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-6">
                    {items.map((item) => (
                      <MangaCard key={item.id} manga={item.manga} showSource={false} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
