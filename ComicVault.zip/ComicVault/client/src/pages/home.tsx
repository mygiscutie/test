import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import MangaCard from "@/components/manga-card";
import { type Manga } from "@shared/schema";

export default function Home() {
  const { data: featuredManga, isLoading } = useQuery<Manga[]>({
    queryKey: ["/api/manga"],
    select: (data) => data?.slice(0, 6) || [],
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-accent/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl md:text-6xl font-bold mb-6">
              Discover Your Next
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {" "}Adventure
              </span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Access thousands of manga and manhwa from popular sources. Track your reading progress and discover new stories.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/browse">
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3" data-testid="button-start-reading">
                  Start Reading
                </Button>
              </Link>
              <Link href="/library">
                <Button variant="secondary" className="px-8 py-3" data-testid="button-browse-library">
                  Browse Library
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-2xl font-bold">Featured This Week</h3>
            <Link href="/browse">
              <Button variant="ghost" className="text-primary hover:text-primary/80" data-testid="button-view-all-featured">
                View All
              </Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="aspect-[3/4] bg-muted rounded-lg animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {featuredManga?.map((manga) => (
                <MangaCard key={manga.id} manga={manga} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Reading Interface Preview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Immersive Reading Experience</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Switch between manga and manhwa reading modes. Customize your experience with themes, zoom levels, and navigation preferences.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Manga Reader Mode */}
            <div className="bg-card rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold">Manga Mode</h4>
                <span className="text-xs bg-muted px-2 py-1 rounded">Page-by-Page</span>
              </div>
              <div className="aspect-[3/4] bg-muted rounded-lg overflow-hidden relative">
                <img
                  src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800"
                  alt="Manga reading interface"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                  <Button variant="secondary" size="sm">
                    ← Previous
                  </Button>
                  <span className="bg-black/70 text-white px-3 py-1 rounded-md text-sm">
                    Page 15/24
                  </span>
                  <Button variant="secondary" size="sm">
                    Next →
                  </Button>
                </div>
              </div>
            </div>

            {/* Manhwa Reader Mode */}
            <div className="bg-card rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold">Manhwa Mode</h4>
                <span className="text-xs bg-muted px-2 py-1 rounded">Vertical Scroll</span>
              </div>
              <div className="aspect-[3/4] bg-muted rounded-lg overflow-hidden relative">
                <div className="h-full overflow-y-auto scrollbar-hide">
                  <img
                    src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
                    alt="Manhwa panel"
                    className="w-full"
                  />
                  <img
                    src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
                    alt="Manhwa panel"
                    className="w-full"
                  />
                  <img
                    src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
                    alt="Manhwa panel"
                    className="w-full"
                  />
                </div>
                <div className="absolute top-4 right-4">
                  <div className="bg-black/70 text-white px-3 py-1 rounded-md text-sm">
                    Ch. 45: The Return
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
