import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Star, Heart, BookOpen, Clock, Check, X, Pause } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { type Manga, type Chapter, type UserLibrary } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MangaDetailsProps {
  params: { id: string };
}

const MOCK_USER_ID = "user1"; // For MVP, using mock user ID

export default function MangaDetails({ params }: MangaDetailsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: manga, isLoading: mangaLoading } = useQuery<Manga>({
    queryKey: ["/api/manga", params.id],
  });

  const { data: chapters, isLoading: chaptersLoading } = useQuery<Chapter[]>({
    queryKey: ["/api/manga", params.id, "chapters"],
    enabled: !!manga,
  });

  const { data: libraryItem } = useQuery<UserLibrary>({
    queryKey: ["/api/library", MOCK_USER_ID, "item", params.id],
    queryFn: async () => {
      const response = await fetch(`/api/library/${MOCK_USER_ID}`);
      if (!response.ok) return null;
      const library = await response.json();
      return library.find((item: any) => item.mangaId === params.id) || null;
    },
  });

  const addToLibraryMutation = useMutation({
    mutationFn: async (data: { status: string }) => {
      return apiRequest("POST", "/api/library", {
        userId: MOCK_USER_ID,
        mangaId: params.id,
        status: data.status,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/library"] });
      toast({ title: "Added to library successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to add to library", variant: "destructive" });
    },
  });

  const updateLibraryMutation = useMutation({
    mutationFn: async (data: { status?: string; isFavorite?: boolean }) => {
      return apiRequest("PUT", `/api/library/${MOCK_USER_ID}/${params.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/library"] });
      toast({ title: "Library updated successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to update library", variant: "destructive" });
    },
  });

  const removeFromLibraryMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/library/${MOCK_USER_ID}/${params.id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/library"] });
      toast({ title: "Removed from library successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to remove from library", variant: "destructive" });
    },
  });

  const handleStatusChange = (status: string) => {
    if (libraryItem) {
      updateLibraryMutation.mutate({ status });
    } else {
      addToLibraryMutation.mutate({ status });
    }
  };

  const toggleFavorite = () => {
    if (libraryItem) {
      updateLibraryMutation.mutate({ isFavorite: !libraryItem.isFavorite });
    } else {
      addToLibraryMutation.mutate({ status: "plan_to_read" });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'reading':
        return <BookOpen className="h-4 w-4" />;
      case 'completed':
        return <Check className="h-4 w-4" />;
      case 'on_hold':
        return <Pause className="h-4 w-4" />;
      case 'dropped':
        return <X className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'plan_to_read':
        return 'Plan to Read';
      case 'reading':
        return 'Reading';
      case 'completed':
        return 'Completed';
      case 'on_hold':
        return 'On Hold';
      case 'dropped':
        return 'Dropped';
      default:
        return 'Add to Library';
    }
  };

  if (mangaLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="w-full lg:w-80 aspect-[3/4] bg-muted rounded-lg" />
              <div className="flex-1 space-y-4">
                <div className="h-12 bg-muted rounded" />
                <div className="h-6 bg-muted rounded w-1/2" />
                <div className="space-y-2">
                  <div className="h-4 bg-muted rounded" />
                  <div className="h-4 bg-muted rounded" />
                  <div className="h-4 bg-muted rounded w-3/4" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!manga) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Manga Not Found</h1>
          <p className="text-muted-foreground mb-4">The manga you're looking for doesn't exist.</p>
          <Link href="/browse">
            <Button>Browse Manga</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cover and Basic Info */}
          <div className="lg:col-span-1">
            <Card className="overflow-hidden">
              <div className="aspect-[3/4] relative">
                <img
                  src={manga.coverImage || "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800"}
                  alt={`${manga.title} cover`}
                  className="w-full h-full object-cover"
                  data-testid="img-manga-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <Badge className="bg-primary text-primary-foreground">
                    {manga.type.toUpperCase()}
                  </Badge>
                  <Badge variant="outline">
                    {manga.status.toUpperCase()}
                  </Badge>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Rating</span>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="font-medium" data-testid="text-rating">
                        {manga.rating ? (manga.rating / 10).toFixed(1) : 'N/A'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Chapters</span>
                    <span className="font-medium" data-testid="text-total-chapters">{manga.latestChapter}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Source</span>
                    <Badge variant="secondary">{manga.source.toUpperCase()}</Badge>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Title and Actions */}
            <div>
              <h1 className="text-4xl font-bold mb-2" data-testid="text-manga-title">{manga.title}</h1>
              <p className="text-muted-foreground mb-4">
                by {manga.author} {manga.artist && manga.artist !== manga.author && `• Art by ${manga.artist}`}
              </p>

              <div className="flex flex-wrap gap-2 mb-6">
                {manga.genres.map((genre) => (
                  <Badge key={genre} variant="outline" className="genre-tag">
                    {genre}
                  </Badge>
                ))}
              </div>

              <div className="flex flex-wrap gap-4">
                <Select value={libraryItem?.status || ""} onValueChange={handleStatusChange}>
                  <SelectTrigger className="w-[200px]" data-testid="select-library-status">
                    <div className="flex items-center space-x-2">
                      {libraryItem && getStatusIcon(libraryItem.status)}
                      <SelectValue placeholder="Add to Library" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="plan_to_read">Plan to Read</SelectItem>
                    <SelectItem value="reading">Reading</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="on_hold">On Hold</SelectItem>
                    <SelectItem value="dropped">Dropped</SelectItem>
                  </SelectContent>
                </Select>

                <Button
                  variant={libraryItem?.isFavorite ? "default" : "outline"}
                  onClick={toggleFavorite}
                  disabled={addToLibraryMutation.isPending || updateLibraryMutation.isPending}
                  data-testid="button-toggle-favorite"
                >
                  <Heart className={`h-4 w-4 mr-2 ${libraryItem?.isFavorite ? 'fill-current' : ''}`} />
                  {libraryItem?.isFavorite ? 'Favorited' : 'Add to Favorites'}
                </Button>

                {libraryItem && (
                  <Button
                    variant="destructive"
                    onClick={() => removeFromLibraryMutation.mutate()}
                    disabled={removeFromLibraryMutation.isPending}
                    data-testid="button-remove-from-library"
                  >
                    Remove from Library
                  </Button>
                )}
              </div>
            </div>

            {/* Description */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Synopsis</h3>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-description">
                {manga.description || "No description available."}
              </p>
            </Card>

            {/* Chapters List */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Chapters</h3>
              {chaptersLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="h-12 bg-muted rounded animate-pulse" />
                  ))}
                </div>
              ) : chapters && chapters.length > 0 ? (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {chapters.map((chapter) => (
                    <Link key={chapter.id} href={`/read/${manga.id}/${chapter.id}`}>
                      <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer group" data-testid={`chapter-item-${chapter.id}`}>
                        <div>
                          <h4 className="font-medium group-hover:text-primary transition-colors">
                            Chapter {chapter.chapterNumber}
                            {chapter.title && `: ${chapter.title}`}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {chapter.releaseDate ? new Date(chapter.releaseDate).toLocaleDateString() : 'Unknown date'}
                          </p>
                        </div>
                        <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                          Read
                        </Button>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">
                  No chapters available yet.
                </p>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
