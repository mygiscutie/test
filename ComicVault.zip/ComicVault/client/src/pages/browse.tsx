import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Grid, List, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import MangaCard from "@/components/manga-card";
import Filters from "@/components/filters";
import { type Manga } from "@shared/schema";

export default function Browse() {
  const [filters, setFilters] = useState<{
    type?: string;
    status?: string;
    genres?: string[];
    search?: string;
  }>({});
  const [sortBy, setSortBy] = useState("latest");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Get search query from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const search = urlParams.get('search');
    if (search) {
      setFilters(prev => ({ ...prev, search }));
    }
  }, []);

  const { data: manga, isLoading } = useQuery<Manga[]>({
    queryKey: ["/api/manga", filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.type) params.append('type', filters.type);
      if (filters.status) params.append('status', filters.status);
      if (filters.genres) {
        filters.genres.forEach(genre => params.append('genres', genre));
      }
      if (filters.search) params.append('search', filters.search);

      const response = await fetch(`/api/manga?${params}`);
      if (!response.ok) throw new Error('Failed to fetch manga');
      return response.json();
    },
  });

  const sortedManga = manga ? [...manga].sort((a, b) => {
    switch (sortBy) {
      case 'popularity':
        return (b.rating || 0) - (a.rating || 0);
      case 'rating':
        return (b.rating || 0) - (a.rating || 0);
      case 'title':
        return a.title.localeCompare(b.title);
      case 'latest':
      default:
        return (b.latestChapter ?? 0) - (a.latestChapter ?? 0);
    }
  }) : [];

  return (
    <section className="py-8 bg-card/30 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <Filters onFiltersChange={setFilters} />
          </div>

          {/* Content Grid */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <h3 className="text-xl font-semibold">Browse All</h3>
                <span className="text-muted-foreground" data-testid="text-results-count">
                  {sortedManga.length} results
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]" data-testid="select-sort">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="latest">Latest Updates</SelectItem>
                    <SelectItem value="popularity">Most Popular</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="title">A-Z</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                  data-testid="button-view-grid"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                  data-testid="button-view-list"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-6">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div key={i} className="aspect-[3/4] bg-muted rounded-lg animate-pulse" />
                ))}
              </div>
            ) : sortedManga.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">No manga found matching your criteria.</p>
                <p className="text-muted-foreground text-sm mt-2">Try adjusting your filters or search terms.</p>
              </div>
            ) : (
              <>
                <div className={
                  viewMode === "grid"
                    ? "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-6"
                    : "space-y-4"
                }>
                  {sortedManga.map((mangaItem) => (
                    <MangaCard
                      key={mangaItem.id}
                      manga={mangaItem}
                      className={viewMode === "list" ? "flex flex-row aspect-auto" : ""}
                    />
                  ))}
                </div>

                {/* Pagination */}
                <div className="flex justify-center mt-12">
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="icon" disabled data-testid="button-previous-page">
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button className="bg-primary text-primary-foreground">1</Button>
                    <Button variant="outline">2</Button>
                    <Button variant="outline">3</Button>
                    <span className="px-3 py-2 text-muted-foreground">...</span>
                    <Button variant="outline">28</Button>
                    <Button variant="outline" size="icon" data-testid="button-next-page">
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
