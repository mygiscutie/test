import { type Manga, type InsertManga, type Chapter, type InsertChapter, type UserLibrary, type InsertUserLibrary, type ReadingProgress, type InsertReadingProgress } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Manga operations
  getManga(id: string): Promise<Manga | undefined>;
  getAllManga(filters?: { type?: string; status?: string; genres?: string[]; search?: string }): Promise<Manga[]>;
  createManga(manga: InsertManga): Promise<Manga>;
  updateManga(id: string, manga: Partial<InsertManga>): Promise<Manga | undefined>;
  
  // Chapter operations
  getChapter(id: string): Promise<Chapter | undefined>;
  getChaptersByManga(mangaId: string): Promise<Chapter[]>;
  createChapter(chapter: InsertChapter): Promise<Chapter>;
  
  // User library operations
  getUserLibrary(userId: string): Promise<UserLibrary[]>;
  getUserLibraryItem(userId: string, mangaId: string): Promise<UserLibrary | undefined>;
  addToLibrary(library: InsertUserLibrary): Promise<UserLibrary>;
  updateLibraryItem(userId: string, mangaId: string, update: Partial<InsertUserLibrary>): Promise<UserLibrary | undefined>;
  removeFromLibrary(userId: string, mangaId: string): Promise<boolean>;
  
  // Reading progress operations
  getReadingProgress(userId: string, mangaId: string, chapterId: string): Promise<ReadingProgress | undefined>;
  updateReadingProgress(progress: InsertReadingProgress): Promise<ReadingProgress>;
  getUserReadingStats(userId: string): Promise<any>;
}

export class MemStorage implements IStorage {
  private manga: Map<string, Manga>;
  private chapters: Map<string, Chapter>;
  private userLibrary: Map<string, UserLibrary>;
  private readingProgress: Map<string, ReadingProgress>;

  constructor() {
    this.manga = new Map();
    this.chapters = new Map();
    this.userLibrary = new Map();
    this.readingProgress = new Map();
    
    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add some sample manga
    const sampleManga: Manga[] = [
      {
        id: "1",
        title: "Solo Leveling",
        description: "10 years ago, after \"the Gate\" that connected the real world with the monster world opened, some of the ordinary, everyday people received the power to hunt monsters within the Gate. They are known as \"Hunters\". However, not all Hunters are powerful.",
        coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        type: "manhwa",
        status: "completed",
        genres: ["Action", "Adventure", "Fantasy"],
        rating: 95,
        latestChapter: 179,
        source: "asura",
        sourceUrl: "https://asuracomic.net/solo-leveling",
        author: "Chugong",
        artist: "DUBU"
      },
      {
        id: "2",
        title: "Tower of God",
        description: "What do you desire? Money and wealth? Honor and pride? Authority and power? Or something that transcends them all? Whatever you desire—it's here.",
        coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        type: "webtoon",
        status: "ongoing",
        genres: ["Action", "Adventure", "Drama", "Fantasy"],
        rating: 89,
        latestChapter: 596,
        source: "webtoon",
        sourceUrl: "https://www.webtoons.com/en/fantasy/tower-of-god",
        author: "SIU",
        artist: "SIU"
      },
      {
        id: "3",
        title: "One Piece",
        description: "Gol D. Roger was known as the \"Pirate King,\" the strongest and most infamous being to have sailed the Grand Line. The capture and death of Roger by the World Government brought a change throughout the world.",
        coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        type: "manga",
        status: "ongoing",
        genres: ["Action", "Adventure", "Comedy", "Drama"],
        rating: 92,
        latestChapter: 1098,
        source: "bato",
        sourceUrl: "https://bato.si/series/one-piece",
        author: "Oda Eiichiro",
        artist: "Oda Eiichiro"
      }
    ];

    sampleManga.forEach(manga => this.manga.set(manga.id, manga));

    // Add some sample chapters with mock page data
    const sampleChapters: Chapter[] = [
      {
        id: "ch1",
        mangaId: "1", // Solo Leveling
        chapterNumber: 1,
        title: "The World's Weakest Hunter",
        pages: [
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1200",
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1200",
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1200"
        ],
        sourceUrl: "https://asuracomic.net/solo-leveling/1",
        releaseDate: new Date("2023-01-01")
      },
      {
        id: "ch2",
        mangaId: "2", // Tower of God  
        chapterNumber: 1,
        title: "Headon's Floor",
        pages: [
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=1500",
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=1200",
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=1000"
        ],
        sourceUrl: "https://www.webtoons.com/en/fantasy/tower-of-god/1",
        releaseDate: new Date("2023-01-01")
      }
    ];

    sampleChapters.forEach(chapter => this.chapters.set(chapter.id, chapter));
  }

  async getManga(id: string): Promise<Manga | undefined> {
    return this.manga.get(id);
  }

  async getAllManga(filters?: { type?: string; status?: string; genres?: string[]; search?: string }): Promise<Manga[]> {
    let results = Array.from(this.manga.values());

    if (filters) {
      if (filters.type) {
        results = results.filter(m => m.type === filters.type);
      }
      if (filters.status) {
        results = results.filter(m => m.status === filters.status);
      }
      if (filters.genres && filters.genres.length > 0) {
        results = results.filter(m => 
          filters.genres!.some(genre => m.genres.includes(genre))
        );
      }
      if (filters.search) {
        const search = filters.search.toLowerCase();
        results = results.filter(m => 
          m.title.toLowerCase().includes(search) ||
          m.description?.toLowerCase().includes(search) ||
          m.author?.toLowerCase().includes(search)
        );
      }
    }

    return results;
  }

  async createManga(insertManga: InsertManga): Promise<Manga> {
    const id = randomUUID();
    const manga: Manga = { 
      ...insertManga, 
      id,
      description: insertManga.description ?? null,
      coverImage: insertManga.coverImage ?? null,
      rating: insertManga.rating ?? null,
      latestChapter: insertManga.latestChapter ?? null,
      author: insertManga.author ?? null,
      artist: insertManga.artist ?? null,
      genres: insertManga.genres ?? []
    };
    this.manga.set(id, manga);
    return manga;
  }

  async updateManga(id: string, update: Partial<InsertManga>): Promise<Manga | undefined> {
    const existing = this.manga.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...update };
    this.manga.set(id, updated);
    return updated;
  }

  async getChapter(id: string): Promise<Chapter | undefined> {
    return this.chapters.get(id);
  }

  async getChaptersByManga(mangaId: string): Promise<Chapter[]> {
    return Array.from(this.chapters.values())
      .filter(c => c.mangaId === mangaId)
      .sort((a, b) => a.chapterNumber - b.chapterNumber);
  }

  async createChapter(insertChapter: InsertChapter): Promise<Chapter> {
    const id = randomUUID();
    const chapter: Chapter = { 
      ...insertChapter, 
      id,
      title: insertChapter.title ?? null,
      pages: insertChapter.pages ?? [],
      releaseDate: insertChapter.releaseDate || new Date()
    };
    this.chapters.set(id, chapter);
    return chapter;
  }

  async getUserLibrary(userId: string): Promise<UserLibrary[]> {
    return Array.from(this.userLibrary.values())
      .filter(item => item.userId === userId);
  }

  async getUserLibraryItem(userId: string, mangaId: string): Promise<UserLibrary | undefined> {
    return Array.from(this.userLibrary.values())
      .find(item => item.userId === userId && item.mangaId === mangaId);
  }

  async addToLibrary(insertLibrary: InsertUserLibrary): Promise<UserLibrary> {
    const id = randomUUID();
    const library: UserLibrary = { 
      ...insertLibrary, 
      id,
      rating: insertLibrary.rating ?? null,
      currentChapter: insertLibrary.currentChapter ?? null,
      isFavorite: insertLibrary.isFavorite ?? null,
      startedAt: insertLibrary.status === 'reading' ? new Date() : null,
      completedAt: insertLibrary.status === 'completed' ? new Date() : null,
    };
    this.userLibrary.set(id, library);
    return library;
  }

  async updateLibraryItem(userId: string, mangaId: string, update: Partial<InsertUserLibrary>): Promise<UserLibrary | undefined> {
    const existing = Array.from(this.userLibrary.values())
      .find(item => item.userId === userId && item.mangaId === mangaId);
    
    if (!existing) return undefined;

    const updated: UserLibrary = { 
      ...existing, 
      ...update,
      startedAt: update.status === 'reading' && !existing.startedAt ? new Date() : existing.startedAt,
      completedAt: update.status === 'completed' ? new Date() : (update.status !== 'completed' ? null : existing.completedAt),
    };
    
    this.userLibrary.set(existing.id, updated);
    return updated;
  }

  async removeFromLibrary(userId: string, mangaId: string): Promise<boolean> {
    const existing = Array.from(this.userLibrary.entries())
      .find(([_, item]) => item.userId === userId && item.mangaId === mangaId);
    
    if (!existing) return false;
    
    this.userLibrary.delete(existing[0]);
    return true;
  }

  async getReadingProgress(userId: string, mangaId: string, chapterId: string): Promise<ReadingProgress | undefined> {
    return Array.from(this.readingProgress.values())
      .find(p => p.userId === userId && p.mangaId === mangaId && p.chapterId === chapterId);
  }

  async updateReadingProgress(insertProgress: InsertReadingProgress): Promise<ReadingProgress> {
    const key = `${insertProgress.userId}-${insertProgress.mangaId}-${insertProgress.chapterId}`;
    const existing = Array.from(this.readingProgress.entries())
      .find(([_, p]) => 
        p.userId === insertProgress.userId && 
        p.mangaId === insertProgress.mangaId && 
        p.chapterId === insertProgress.chapterId
      );

    const progress: ReadingProgress = {
      id: existing ? existing[1].id : randomUUID(),
      ...insertProgress,
      pageNumber: insertProgress.pageNumber ?? null,
      scrollPosition: insertProgress.scrollPosition ?? null,
      isCompleted: insertProgress.isCompleted ?? null,
      lastReadAt: new Date(),
    };

    if (existing) {
      this.readingProgress.set(existing[0], progress);
    } else {
      this.readingProgress.set(progress.id, progress);
    }

    return progress;
  }

  async getUserReadingStats(userId: string): Promise<any> {
    const library = await this.getUserLibrary(userId);
    const progress = Array.from(this.readingProgress.values())
      .filter(p => p.userId === userId);

    const stats = {
      totalManga: library.length,
      planToRead: library.filter(item => item.status === 'plan_to_read').length,
      reading: library.filter(item => item.status === 'reading').length,
      completed: library.filter(item => item.status === 'completed').length,
      onHold: library.filter(item => item.status === 'on_hold').length,
      dropped: library.filter(item => item.status === 'dropped').length,
      chaptersRead: progress.filter(p => p.isCompleted).length,
      readingStreak: 12, // Mock data
      favoriteGenre: "Action", // Mock data
      hoursRead: 47, // Mock data
      monthlyGoalProgress: 75, // Mock data
    };

    return stats;
  }
}

export const storage = new MemStorage();
