import * as cheerio from 'cheerio';
import { storage } from '../storage';
import { type InsertManga, type InsertChapter } from '@shared/schema';

interface ScrapedManga {
  title: string;
  description?: string;
  coverImage?: string;
  type: string;
  status: string;
  genres: string[];
  latestChapter: number;
  author?: string;
  artist?: string;
}

interface ScrapedChapter {
  chapterNumber: number;
  title?: string;
  pages: string[];
}

export class MangaScraper {
  private readonly sources = {
    asura: 'https://asuracomic.net',
    bato: 'https://bato.si',
    flame: 'https://flamecomics.com',
    webtoon: 'https://www.webtoons.com'
  };

  async scrapeAsuraManga(url: string): Promise<ScrapedManga | null> {
    try {
      const response = await fetch(url);
      if (!response.ok) return null;
      
      const html = await response.text();
      const $ = cheerio.load(html);

      // This is a simplified example - real scraping would need to handle
      // actual DOM structure of each site
      const title = $('.manga-title, h1').first().text().trim();
      const description = $('.manga-description, .summary').first().text().trim();
      const coverImage = $('.manga-cover img, .cover img').first().attr('src');
      const genres = $('.genres a, .genre-tags a').map((_, el) => $(el).text().trim()).get();
      const latestChapter = parseInt($('.latest-chapter').text().replace(/\D/g, '')) || 0;

      return {
        title,
        description,
        coverImage,
        type: 'manhwa',
        status: 'ongoing',
        genres,
        latestChapter,
        author: $('.author').text().trim(),
        artist: $('.artist').text().trim()
      };
    } catch (error) {
      console.error('Error scraping Asura manga:', error);
      return null;
    }
  }

  async scrapeBatoManga(url: string): Promise<ScrapedManga | null> {
    try {
      const response = await fetch(url);
      if (!response.ok) return null;
      
      const html = await response.text();
      const $ = cheerio.load(html);

      const title = $('h3, .title').first().text().trim();
      const description = $('.summary, .description').first().text().trim();
      const coverImage = $('.cover img, .manga-cover img').first().attr('src');
      const genres = $('.genres span, .tags a').map((_, el) => $(el).text().trim()).get();
      const latestChapter = parseInt($('.chapter-list .chapter:first').text().replace(/\D/g, '')) || 0;

      return {
        title,
        description,
        coverImage,
        type: 'manga',
        status: 'ongoing',
        genres,
        latestChapter,
        author: $('.author-name').text().trim(),
        artist: $('.artist-name').text().trim()
      };
    } catch (error) {
      console.error('Error scraping Bato manga:', error);
      return null;
    }
  }

  async scrapeChapter(mangaId: string, chapterUrl: string, source: string): Promise<ScrapedChapter | null> {
    try {
      const response = await fetch(chapterUrl);
      if (!response.ok) return null;
      
      const html = await response.text();
      const $ = cheerio.load(html);

      let pages: string[] = [];
      let chapterNumber = 0;
      let title = '';

      if (source === 'asura') {
        pages = $('.chapter-images img, .reader-images img')
          .map((_, el) => $(el).attr('src') || $(el).attr('data-src'))
          .get()
          .filter(Boolean);
        
        chapterNumber = parseInt($('.chapter-title, .chapter-number').text().replace(/\D/g, '')) || 0;
        title = $('.chapter-title').text().trim();
      } else if (source === 'bato') {
        pages = $('.page-img img, .reader img')
          .map((_, el) => $(el).attr('src') || $(el).attr('data-src'))
          .get()
          .filter(Boolean);
        
        chapterNumber = parseInt($('.chapter-title').text().replace(/\D/g, '')) || 0;
        title = $('.chapter-title').text().trim();
      }

      return {
        chapterNumber,
        title,
        pages
      };
    } catch (error) {
      console.error('Error scraping chapter:', error);
      return null;
    }
  }

  async updateMangaFromSource(mangaId: string): Promise<boolean> {
    try {
      const manga = await storage.getManga(mangaId);
      if (!manga) return false;

      let scrapedData: ScrapedManga | null = null;

      switch (manga.source) {
        case 'asura':
          scrapedData = await this.scrapeAsuraManga(manga.sourceUrl);
          break;
        case 'bato':
          scrapedData = await this.scrapeBatoManga(manga.sourceUrl);
          break;
        // Add more sources as needed
        default:
          return false;
      }

      if (!scrapedData) return false;

      await storage.updateManga(mangaId, {
        description: scrapedData.description || manga.description,
        status: scrapedData.status,
        latestChapter: scrapedData.latestChapter,
        genres: scrapedData.genres.length > 0 ? scrapedData.genres : manga.genres
      });

      return true;
    } catch (error) {
      console.error('Error updating manga from source:', error);
      return false;
    }
  }

  async discoverNewManga(source: string, page: number = 1): Promise<string[]> {
    // This would implement discovering new manga from source homepages
    // Returns array of manga URLs to be scraped
    const discoveredUrls: string[] = [];
    
    try {
      let baseUrl = '';
      switch (source) {
        case 'asura':
          baseUrl = `${this.sources.asura}/manga?page=${page}`;
          break;
        case 'bato':
          baseUrl = `${this.sources.bato}/browse?page=${page}`;
          break;
        default:
          return [];
      }

      const response = await fetch(baseUrl);
      if (!response.ok) return [];
      
      const html = await response.text();
      const $ = cheerio.load(html);

      // Extract manga URLs from listing pages
      $('.manga-item a, .series-item a').each((_, el) => {
        const href = $(el).attr('href');
        if (href) {
          const fullUrl = href.startsWith('http') ? href : `${this.sources[source as keyof typeof this.sources]}${href}`;
          discoveredUrls.push(fullUrl);
        }
      });

    } catch (error) {
      console.error(`Error discovering manga from ${source}:`, error);
    }

    return discoveredUrls;
  }
}

export const scraper = new MangaScraper();
