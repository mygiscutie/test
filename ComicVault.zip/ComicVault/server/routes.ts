import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { scraper } from "./services/scraper";
import { insertMangaSchema, insertUserLibrarySchema, insertReadingProgressSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Manga routes
  app.get("/api/manga", async (req, res) => {
    try {
      const { type, status, genres, search } = req.query;
      const filters = {
        type: type as string,
        status: status as string,
        genres: genres ? (Array.isArray(genres) ? genres as string[] : [genres as string]) : undefined,
        search: search as string,
      };

      const manga = await storage.getAllManga(filters);
      res.json(manga);
    } catch (error) {
      console.error("Error fetching manga:", error);
      res.status(500).json({ message: "Failed to fetch manga" });
    }
  });

  app.get("/api/manga/:id", async (req, res) => {
    try {
      const manga = await storage.getManga(req.params.id);
      if (!manga) {
        return res.status(404).json({ message: "Manga not found" });
      }
      res.json(manga);
    } catch (error) {
      console.error("Error fetching manga:", error);
      res.status(500).json({ message: "Failed to fetch manga" });
    }
  });

  app.post("/api/manga", async (req, res) => {
    try {
      const validation = insertMangaSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid manga data", errors: validation.error.errors });
      }

      const manga = await storage.createManga(validation.data);
      res.status(201).json(manga);
    } catch (error) {
      console.error("Error creating manga:", error);
      res.status(500).json({ message: "Failed to create manga" });
    }
  });

  // Chapter routes
  app.get("/api/manga/:id/chapters", async (req, res) => {
    try {
      const chapters = await storage.getChaptersByManga(req.params.id);
      res.json(chapters);
    } catch (error) {
      console.error("Error fetching chapters:", error);
      res.status(500).json({ message: "Failed to fetch chapters" });
    }
  });

  app.get("/api/chapters/:id", async (req, res) => {
    try {
      const chapter = await storage.getChapter(req.params.id);
      if (!chapter) {
        return res.status(404).json({ message: "Chapter not found" });
      }
      res.json(chapter);
    } catch (error) {
      console.error("Error fetching chapter:", error);
      res.status(500).json({ message: "Failed to fetch chapter" });
    }
  });

  // User library routes
  app.get("/api/library/:userId", async (req, res) => {
    try {
      const library = await storage.getUserLibrary(req.params.userId);
      
      // Enrich with manga details
      const enrichedLibrary = await Promise.all(
        library.map(async (item) => {
          const manga = await storage.getManga(item.mangaId);
          return { ...item, manga };
        })
      );

      res.json(enrichedLibrary);
    } catch (error) {
      console.error("Error fetching user library:", error);
      res.status(500).json({ message: "Failed to fetch library" });
    }
  });

  app.post("/api/library", async (req, res) => {
    try {
      const validation = insertUserLibrarySchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid library data", errors: validation.error.errors });
      }

      const libraryItem = await storage.addToLibrary(validation.data);
      res.status(201).json(libraryItem);
    } catch (error) {
      console.error("Error adding to library:", error);
      res.status(500).json({ message: "Failed to add to library" });
    }
  });

  app.put("/api/library/:userId/:mangaId", async (req, res) => {
    try {
      const { userId, mangaId } = req.params;
      const update = req.body;

      const updatedItem = await storage.updateLibraryItem(userId, mangaId, update);
      if (!updatedItem) {
        return res.status(404).json({ message: "Library item not found" });
      }

      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating library item:", error);
      res.status(500).json({ message: "Failed to update library item" });
    }
  });

  app.delete("/api/library/:userId/:mangaId", async (req, res) => {
    try {
      const { userId, mangaId } = req.params;
      const removed = await storage.removeFromLibrary(userId, mangaId);
      
      if (!removed) {
        return res.status(404).json({ message: "Library item not found" });
      }

      res.json({ message: "Item removed from library" });
    } catch (error) {
      console.error("Error removing from library:", error);
      res.status(500).json({ message: "Failed to remove from library" });
    }
  });

  // Reading progress routes
  app.post("/api/reading-progress", async (req, res) => {
    try {
      const validation = insertReadingProgressSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid progress data", errors: validation.error.errors });
      }

      const progress = await storage.updateReadingProgress(validation.data);
      res.json(progress);
    } catch (error) {
      console.error("Error updating reading progress:", error);
      res.status(500).json({ message: "Failed to update reading progress" });
    }
  });

  app.get("/api/stats/:userId", async (req, res) => {
    try {
      const stats = await storage.getUserReadingStats(req.params.userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  // Scraper routes
  app.post("/api/scrape/manga", async (req, res) => {
    try {
      const { url, source } = req.body;
      
      if (!url || !source) {
        return res.status(400).json({ message: "URL and source are required" });
      }

      let scrapedData = null;
      switch (source) {
        case 'asura':
          scrapedData = await scraper.scrapeAsuraManga(url);
          break;
        case 'bato':
          scrapedData = await scraper.scrapeBatoManga(url);
          break;
        default:
          return res.status(400).json({ message: "Unsupported source" });
      }

      if (!scrapedData) {
        return res.status(400).json({ message: "Failed to scrape manga data" });
      }

      const manga = await storage.createManga({
        ...scrapedData,
        sourceUrl: url,
        source
      });

      res.status(201).json(manga);
    } catch (error) {
      console.error("Error scraping manga:", error);
      res.status(500).json({ message: "Failed to scrape manga" });
    }
  });

  app.post("/api/scrape/discover/:source", async (req, res) => {
    try {
      const { source } = req.params;
      const { page = 1 } = req.query;
      
      const urls = await scraper.discoverNewManga(source, Number(page));
      res.json({ urls });
    } catch (error) {
      console.error("Error discovering manga:", error);
      res.status(500).json({ message: "Failed to discover manga" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
