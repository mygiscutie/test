import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const manga = pgTable("manga", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  coverImage: text("cover_image"),
  type: text("type").notNull(), // manga, manhwa, webtoon
  status: text("status").notNull(), // ongoing, completed, hiatus
  genres: text("genres").array().notNull().default([]),
  rating: integer("rating").default(0), // out of 100
  latestChapter: integer("latest_chapter").default(0),
  source: text("source").notNull(), // asura, bato, flame, etc
  sourceUrl: text("source_url").notNull(),
  author: text("author"),
  artist: text("artist"),
});

export const chapters = pgTable("chapters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mangaId: varchar("manga_id").notNull().references(() => manga.id),
  chapterNumber: integer("chapter_number").notNull(),
  title: text("title"),
  pages: text("pages").array().notNull().default([]), // array of image URLs
  sourceUrl: text("source_url").notNull(),
  releaseDate: timestamp("release_date"),
});

export const userLibrary = pgTable("user_library", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(), // simplified for MVP
  mangaId: varchar("manga_id").notNull().references(() => manga.id),
  status: text("status").notNull(), // plan_to_read, reading, completed, on_hold, dropped
  currentChapter: integer("current_chapter").default(0),
  rating: integer("rating"), // user's personal rating
  isFavorite: boolean("is_favorite").default(false),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
});

export const readingProgress = pgTable("reading_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  mangaId: varchar("manga_id").notNull().references(() => manga.id),
  chapterId: varchar("chapter_id").notNull().references(() => chapters.id),
  pageNumber: integer("page_number").default(0),
  scrollPosition: integer("scroll_position").default(0),
  isCompleted: boolean("is_completed").default(false),
  lastReadAt: timestamp("last_read_at").default(sql`now()`),
});

export const insertMangaSchema = createInsertSchema(manga).omit({
  id: true,
});

export const insertChapterSchema = createInsertSchema(chapters).omit({
  id: true,
});

export const insertUserLibrarySchema = createInsertSchema(userLibrary).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export const insertReadingProgressSchema = createInsertSchema(readingProgress).omit({
  id: true,
  lastReadAt: true,
});

export type Manga = typeof manga.$inferSelect;
export type InsertManga = z.infer<typeof insertMangaSchema>;
export type Chapter = typeof chapters.$inferSelect;
export type InsertChapter = z.infer<typeof insertChapterSchema>;
export type UserLibrary = typeof userLibrary.$inferSelect;
export type InsertUserLibrary = z.infer<typeof insertUserLibrarySchema>;
export type ReadingProgress = typeof readingProgress.$inferSelect;
export type InsertReadingProgress = z.infer<typeof insertReadingProgressSchema>;
