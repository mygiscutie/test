# MangaVerse - Full-Stack Manga Reading Platform

## Overview

MangaVerse is a comprehensive manga and manhwa reading platform built with modern web technologies. It provides users with the ability to browse, read, and track their manga collection across multiple sources. The application features a responsive design optimized for both desktop and mobile reading experiences, with support for different reading modes and progress tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built using React with TypeScript, leveraging the following key architectural decisions:

- **Component-Based Architecture**: Utilizes React functional components with hooks for state management and side effects
- **Routing**: Implements client-side routing using Wouter library for lightweight navigation
- **State Management**: Uses TanStack Query (React Query) for server state management and caching, eliminating the need for complex global state solutions
- **UI Component System**: Built on shadcn/ui components with Radix UI primitives, providing accessible and customizable interface elements
- **Styling**: Tailwind CSS with CSS custom properties for theming, supporting dark mode and consistent design tokens

### Backend Architecture
The server-side follows a REST API pattern with Express.js:

- **Express Server**: Lightweight REST API server with middleware for request logging and error handling
- **Type-Safe Database Layer**: Uses Drizzle ORM with PostgreSQL for type-safe database operations and migrations
- **Storage Abstraction**: Implements an interface-based storage pattern allowing for multiple storage backends (currently uses in-memory storage for development)
- **Web Scraping Service**: Built-in scraper service for fetching manga content from various sources (Asura, Bato, Flame, Webtoons)

### Data Architecture
The database schema is designed around core entities:

- **Manga**: Central content entity with metadata, source information, and status tracking
- **Chapters**: Individual chapter data with page arrays and source URLs
- **User Library**: Personal collection management with reading status and progress
- **Reading Progress**: Detailed tracking of user position within chapters

### Development Environment
The project uses a monorepo structure with shared TypeScript types:

- **Build System**: Vite for fast development and optimized production builds
- **Development Server**: Hot module replacement with Vite dev server integration
- **Type Safety**: Shared schema definitions between client and server using Zod for validation
- **Database Management**: Drizzle Kit for schema migrations and database operations

### Reading Experience Architecture
The reader component implements multiple viewing modes:

- **Adaptive Reading Modes**: Supports both manga (right-to-left) and manhwa (vertical scroll) reading patterns
- **Progress Tracking**: Automatic progress saving with page position and scroll state
- **Responsive Design**: Mobile-optimized reading experience with touch navigation
- **Settings Persistence**: User preferences for zoom level, reading mode, and display options

### Performance Optimizations
Several architectural decisions optimize performance:

- **Image Loading**: Lazy loading for manga pages and cover images
- **Query Caching**: Aggressive caching strategy with TanStack Query for frequently accessed data
- **Code Splitting**: Route-based code splitting for reduced initial bundle size
- **Static Asset Optimization**: Vite's built-in optimizations for CSS and JavaScript bundling

## External Dependencies

### Core Framework Dependencies
- **React 18**: Frontend framework with concurrent features
- **Express.js**: Backend web framework
- **TypeScript**: Type safety across the full stack
- **Vite**: Build tool and development server

### Database and ORM
- **PostgreSQL**: Primary database (configured for Neon serverless)
- **Drizzle ORM**: Type-safe database toolkit
- **@neondatabase/serverless**: Serverless PostgreSQL driver

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Component library built on Radix UI
- **Radix UI**: Unstyled, accessible UI primitives
- **Lucide React**: Icon library

### State Management and Data Fetching
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Zod**: Schema validation and type inference

### Routing and Navigation
- **Wouter**: Lightweight client-side routing

### Web Scraping
- **Cheerio**: Server-side HTML parsing for content extraction

### Development and Build Tools
- **esbuild**: Fast JavaScript bundler for production
- **tsx**: TypeScript execution environment
- **PostCSS**: CSS processing with Autoprefixer

### Session and Storage
- **connect-pg-simple**: PostgreSQL session store for Express

### Charting and Analytics
- **Recharts**: React charting library for reading statistics

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx**: Conditional className utility
- **class-variance-authority**: Variant-based component styling

The architecture prioritizes developer experience with hot reloading, type safety, and modern tooling while maintaining performance and scalability for the end-user experience.